<?php $__env->startSection('content'); ?>

<div class="card" style="max-width: 750px; margin: 0 auto;">

    <div class="card-header d-sm-flex align-items-center justify-content-between mb-2">
        <h5 class="h3 mb-0 text-gray-800">Editar Cidade (<?php echo e($city->name); ?>)</h5>
        <a href="<?php echo e(route('cities.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('cities.update', $city->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">

                <div class="col-md-12">
                    <div class="form-group">
                        <label for="name">Nome</label>
                        <input type="text" class="form-control" value="<?php echo e(old('name') ?? $city->name); ?>" id="name" name="name">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">

                        <label for="country_code">País</label>
                        <select name="country_id" id="country_id" class="form-control">
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>" <?php if($city->country_id == $country->id): ?> <?php echo e('selected'); ?> <?php endif; ?>
                                ><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">

                        <label for="state_id">Estado</label>
                        <select name="state_id" required id="state_id" class="form-control">
                            <option value="<?php echo e($city->state->id); ?>"><?php echo e($city->state->name); ?></option>
                        </select>

                        <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>

                <div class="col-12">
                    <hr>
                    <div class="float-right">
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

</div>

<script type="text/javascript">
    let currentState = "<?php echo e($city->state_id); ?>";

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
        $('#country_id').on('change', function(e) {
            loadStates();
        });

        function loadStates() {
            var country_id = $("#country_id").val();

            $.ajax({
                url: "<?php echo e(route('get-states')); ?>",
                type: "POST",
                data: {
                    country: country_id
                },
                success: function(data) {
                    console.log(data);
                    $('#state_id').empty();
                    $.each(data.states, function(index, state) {
                        $('#state_id').append('<option value="' + state.id + '">' + state.name + '</option>');
                    })
                }
            })
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projectos\2022\testes_de_emprego\client-management\resources\views/dashboard/city/edit.blade.php ENDPATH**/ ?>