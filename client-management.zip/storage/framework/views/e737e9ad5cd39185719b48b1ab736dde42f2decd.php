<?php $__env->startSection('content'); ?>

<div class="card" style="max-width: 750px; margin: 0 auto;">

    <div class="card-header d-sm-flex align-items-center justify-content-between mb-2">
        <h5 class="h3 mb-0 text-gray-800">Cidades</h5>
        <form method="GET" action="<?php echo e(route('cities.index')); ?>">
            <div class="row align-items-center">
                <div class="col">
                    <input type="search" name="search" class="form-control" value="<?php echo e(request('search') ?? ''); ?>" id="inlineFormInput" placeholder="Pesquisar cidades">
                </div>
                <div class="col">
                    <button type="submit" class="btn
                    btn-primary"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
        <a href="<?php echo e(route('cities.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Cidade</a>
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="">
                    <tr>
                        <th scope="col">#ID</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Estado</th>
                        <th scope="col">País</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row">#<?php echo e($city->id); ?></th>
                        <td><?php echo e($city->name); ?></td>
                        <td><?php echo e($city->state->name); ?></td>
                        <td><?php echo e($city->country->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('cities.destroy', $city->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('cities.edit', $city->id)); ?>" class="btn btn-outline-primary btn-sm"><i class="fa fa-edit"></i></a>
                                    <button type="submit" onclick="return confirm('Tem certeza?')" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>

    </div>
    <div class="card-footer">

        <div class="float-right">
            <?php echo e($cities->links()); ?>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projectos\2022\testes_de_emprego\client-management\resources\views/dashboard/city/index.blade.php ENDPATH**/ ?>