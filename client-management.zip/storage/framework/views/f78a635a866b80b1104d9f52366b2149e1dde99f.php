<?php $__env->startSection('content'); ?>

<div class="card" style="max-width: 900px; margin: 0 auto;">

    <div class="card-header d-sm-flex align-items-center justify-content-between mb-2">
        <h5 class="h3 mb-0 text-gray-800">Países</h5>
        <form method="GET" action="<?php echo e(route('countries.index')); ?>">
            <div class="row align-items-center">
                <div class="col-9">
                    <input type="search" name="search" class="form-control" value="<?php echo e(request('search') ?? ''); ?>" id="inlineFormInput" placeholder="Pesquisar países">
                </div>
                <div class="col-3">
                    <button type="submit" class="btn
                    btn-primary"><i class="fa fa-search"></i></button>
                </div>
            </div>
        </form>
        <a href="<?php echo e(route('countries.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> País</a>
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="">
                    <tr>
                        <th scope="col">#ID</th>
                        <th scope="col">Código do País</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row">#<?php echo e($country->id); ?></th>
                        <td><?php echo e($country->code); ?></td>
                        <td><?php echo e($country->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('countries.destroy', $country->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('countries.edit', $country->id)); ?>" class="btn btn-outline-primary btn-sm"><i class="fa fa-edit"></i></a>
                                    <button type="submit" onclick="return confirm('Tem certeza?')" class="btn btn-outline-danger btn-sm"><i class="fa fa-times"></i></button>
                                </div>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>

    </div>
    <div class="card-footer">
        <?php echo e($countries->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projectos\2022\testes_de_emprego\client-management\resources\views/dashboard/country/index.blade.php ENDPATH**/ ?>