<?php $__env->startSection('content'); ?>
<div id="app">
    <router-view />
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projectos\2022\testes_de_emprego\client-management\resources\views/dashboard/vue/index.blade.php ENDPATH**/ ?>