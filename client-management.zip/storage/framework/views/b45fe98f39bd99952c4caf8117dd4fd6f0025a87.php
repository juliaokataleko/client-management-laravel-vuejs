<?php $__env->startSection('content'); ?>

<div class="card" style="max-width: 600px; margin: 0 auto;">

    <div class="card-header d-sm-flex align-items-center justify-content-between mb-2">
        <h5 class="h3 mb-0 text-gray-800">Editar País (<?php echo e($country->name); ?>)</h5>
        <a href="<?php echo e(route('countries.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Voltar</a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('countries.update', $country->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Nome</label>
                        <input type="text" class="form-control" value="<?php echo e(old('name') ?? $country->name); ?>" id="name" name="name">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="code">Código do País</label>
                        <input type="text" class="form-control" value="<?php echo e(old('code') ?? $country->code); ?>" id="code" name="code">
                    </div>
                </div>
                <div class="col-12">
                    <hr>
                    <div class="float-right">
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projectos\2022\testes_de_emprego\client-management\resources\views/dashboard/country/edit.blade.php ENDPATH**/ ?>