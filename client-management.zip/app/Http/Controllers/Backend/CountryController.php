<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $query = Country::query();

        if (request('search')) {
            $query->where('name', 'like', "%{$request->search}%")
                ->orWhere('country_code', 'like', "%{$request->search}%");
        }
        $countries = $query->paginate(10);

        return view('dashboard.country.index', [
            'countries' => $countries
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.country.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $this->validateData($request);

        $country = Country::create($data);

        return redirect(route('countries.index'))->with('success', 'País registado.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Country $country)
    {
        return view('dashboard.country.edit', [
            'country' => $country
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Country $country)
    {
        $data = $this->validateData($request);
        $country->update($data);

        return redirect(route('countries.index'))->with('success', 'País actualizado.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Country $country)
    {
        $country->delete();
        return redirect(route('countries.index'))->with('success', 'País excluído com sucesso');
    }

    public function validateData(Request $request)
    {
        return $request->validate([
            'name' => 'required|string',
            'code' => 'required|string'
        ]);
    }

    public function getStates()
    {
        $country = request('country');
        $country = Country::find(intval($country));

        return response()->json([
            'states' => $country->states
        ]);
    }
}
