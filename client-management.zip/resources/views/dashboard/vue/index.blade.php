@extends('layouts.app')

@section('content')
<div id="app">
    <router-view />
</div>
@endsection